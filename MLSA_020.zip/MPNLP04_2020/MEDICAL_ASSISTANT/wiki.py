import wikipedia
print (wikipedia.summary("glaucoma", sentences=2))
 
